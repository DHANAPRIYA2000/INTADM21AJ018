export interface AddressModel {

    address: string,  
    city: string,  
    state: string,  
    postcode: string,  
    country: any[],  
    aggrement: boolean
}


