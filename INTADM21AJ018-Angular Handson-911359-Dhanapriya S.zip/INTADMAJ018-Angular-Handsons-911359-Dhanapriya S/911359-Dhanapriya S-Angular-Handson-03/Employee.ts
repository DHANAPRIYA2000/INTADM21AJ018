export interface Employee
{
    Id:string;
    Name:string;
    Salary:number;
    Permanent:boolean;
}